package sortingproject;

import java.util.Random;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TabPane.TabClosingPolicy;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

//importing all necessary imports
public class SortingProject extends Application {
    
    @Override
    public void start(Stage primaryStage) { 
        primaryStage.setTitle("SORTING ALGORITHMS");
        Group root = new Group();
        Scene scene = new 
                    Scene (root, 1000, 1000, Color.WHITE);
        TabPane tabpane = new TabPane();
        tabpane.setTabClosingPolicy(TabClosingPolicy.UNAVAILABLE);
        BorderPane borderpane = new BorderPane();
        //setting up the window, and its dimension
        Tab tab = new Tab();
        tab.setGraphic(new Circle(0,0,10));
        tab.setText("Sorting Intro");
        HBox hbox = new HBox();
        hbox.getChildren().add
        (new Label("Sorting Efficiency" + "\n" + "\n" + "The two main criterias to judge which algorithm is better than the other have been:" + "\n" + "\n" + "    1- Time taken to sort the given data." + ""
                + "\n" + "    2- Memory Space required to do so."));
        hbox.setAlignment(Pos.CENTER);
        tab.setContent(hbox);
        tabpane.getTabs().add(tab);  
        //this is the first tab, where it gives a brief description of the project
        
        
        TextField field1 = new TextField();
        TextField field2 = new TextField();
        TextField field3 = new TextField();
        TextField field4 = new TextField();
        TextField field5 = new TextField();
        TextField field6 = new TextField();
        TextField field7 = new TextField();
        TextField field8 = new TextField();
        TextField field9 = new TextField();
        TextField field10 = new TextField();
        HBox fieldHbox0 = new HBox();
        fieldHbox0.getChildren().addAll(field1, field2, field3, field4, field5, field6, field7, field8, field9, field10);
        
        Button btn0 = new Button("Generate Random Numbers");
        Button btn00 = new Button("Start Bubble Sort");
        Button btn000 = new Button("Reset Numbers");
        HBox buttonHbox0 = new HBox();
        buttonHbox0.setAlignment(Pos.CENTER);
        buttonHbox0.getChildren().addAll(btn0, btn00, btn000);
        
        Label label = new Label();
        Label label2 = new Label();
        
        Tab tab2 = new Tab();
        tab2.setGraphic(new Circle(0,0,10));
        tab2.setText("Bubble Sort");
        HBox hbox2 = new HBox();
        hbox2.getChildren().addAll
        (new Label("\n" + "                             Bubble Sort Description:" + "\n" + "\n" + "   Bubble Sort is the simplest sorting algorithm that works by repeatedly swapping the adjacent elements if they are in the wrong order.") );
        VBox vbox = new VBox();
        vbox.setSpacing(100);
        vbox.getChildren().addAll(hbox2, fieldHbox0, buttonHbox0, label, label2);
        hbox2.setAlignment(Pos.TOP_CENTER);
        tab2.setContent(vbox);
        tabpane.getTabs().add(tab2);
        
        btn000.setOnAction(event -> {
            field1.clear();
            field2.clear();
            field3.clear();
            field4.clear();
            field5.clear();
            field6.clear();
            field7.clear();
            field8.clear();
            field9.clear();
            field10.clear();
            label.setText("");
            label2.setText("");
        });
        //btn00.setOnAction(this::name);
        btn00.setOnAction(event -> {
            int bubbleArray[] = new int[10];
            
            String str1 = field1.getText();
            int num1 = Integer.parseInt(str1);
            bubbleArray[0] = num1;
            
            String str2 = field2.getText();
            int num2 = Integer.parseInt(str2);
            bubbleArray[1] = num2;
            
            String str3 = field3.getText();
            int num3 = Integer.parseInt(str3);
            bubbleArray[2] = num3;
            
            String str4 = field4.getText();
            int num4 = Integer.parseInt(str4);
            bubbleArray[3] = num4;
            
            String str5 = field5.getText();
            int num5 = Integer.parseInt(str5);
            bubbleArray[4] = num5;
            
            String str6 = field6.getText();
            int num6 = Integer.parseInt(str6);
            bubbleArray[5] = num6;
            
            String str7 = field7.getText();
            int num7 = Integer.parseInt(str7);
            bubbleArray[6] = num7;
            
            String str8 = field8.getText();
            int num8 = Integer.parseInt(str8);
            bubbleArray[7] = num8;
            
            String str9 = field9.getText();
            int num9 = Integer.parseInt(str9);
            bubbleArray[8] = num9;
            
            String str10 = field10.getText();
            int num10 = Integer.parseInt(str10);
            bubbleArray[9] = num10;
            
            
            int inputLength = bubbleArray.length;
            int temp;
            boolean is_sorted;
            int counter = 0;
            HBox printHbox = new HBox();
            String string =  "";
        
            for (int i = 0; i < inputLength; i++){
                is_sorted = true;
                for (int j = 1; j < (inputLength-i); j++){
                    if (bubbleArray[j-1] > bubbleArray[j]){
                        for (int k = 0; k < 10; k++) {
                            string = string + Integer.toString(bubbleArray[k]) + " ";
                            if (k == 9) {
                                string = string + "\n";
                            }
                        }
                        
                        counter ++;
                        temp = bubbleArray[j-1];
                        bubbleArray[j-1] = bubbleArray[j];
                        bubbleArray[j] = temp;
                        is_sorted = false;
                    }
                    
                }
                if (is_sorted) break;
                
            }
            String string2 = "";
            for (int i = 0; i <10; i++) {
                string2 = string2 + Integer.toString(bubbleArray[i]) + " ";
            }
            label.setPadding(new Insets(0,100,0,400));
            label.setText(string);
            label2.setPadding(new Insets(0,50,0,400));
            label2.setText("Sorted array: " + string2);
            
                 
        });
        btn0.setOnAction(event -> {
            Random rd = new Random();
                int[] arr = new int[10];
            for (int i = 0; i < arr.length; i++) {
                arr[i] = rd.nextInt(1000); 
                System.out.println(arr[i]);
            }
                
            field1.setText(Integer.toString(arr[0]));   
            field2.setText(Integer.toString(arr[1]));
            field3.setText(Integer.toString(arr[2]));
            field4.setText(Integer.toString(arr[3]));
            field5.setText(Integer.toString(arr[4]));
            field6.setText(Integer.toString(arr[5]));
            field7.setText(Integer.toString(arr[6]));
            field8.setText(Integer.toString(arr[7]));
            field9.setText(Integer.toString(arr[8]));
            field10.setText(Integer.toString(arr[9]));
            
                
        });
        
        
        
        //second tab is for bubble sort
        
        TextField field11 = new TextField();
        TextField field12 = new TextField();
        TextField field13 = new TextField();
        TextField field14 = new TextField();
        TextField field15 = new TextField();
        TextField field16 = new TextField();
        TextField field17 = new TextField();
        TextField field18 = new TextField();
        TextField field19 = new TextField();
        TextField field20 = new TextField();
        HBox fieldHbox1 = new HBox();
        fieldHbox1.getChildren().addAll(field11, field12, field13, field14, field15, field16, field17, field18, field19, field20);
        
        Label label3 = new Label();
        Label label4 = new Label();
        
        Button btn = new Button("Generate Random Numbers");
        Button btn1 = new Button("Start Selection Sort");
        Button btn2 = new Button("Reset Numbers");
        HBox buttonHbox = new HBox();
        buttonHbox.setAlignment(Pos.CENTER);
        buttonHbox.getChildren().addAll(btn, btn1, btn2);
        
        Tab tab3 = new Tab();
        tab3.setGraphic(new Circle(0,0,10));
        tab3.setText("Selection Sort");
        HBox hbox3 = new HBox();
        hbox3.getChildren().add
        (new Label("\n" + "                             Selection Sort Description:" + "\n" + "\n" + "   Selection Sort sorts an array by repeatedly finding the minimum element and putting it at the beginning."));
        VBox vbox1 = new VBox();
        vbox1.setSpacing(100);
        vbox1.getChildren().addAll(hbox3, fieldHbox1, buttonHbox, label3, label4);
        hbox3.setAlignment(Pos.TOP_CENTER);
        tab3.setContent(vbox1);
        tabpane.getTabs().add(tab3); 
        
        
        btn2.setOnAction(event -> {
            field11.clear();
            field12.clear();
            field13.clear();
            field14.clear();
            field15.clear();
            field16.clear();
            field17.clear();
            field18.clear();
            field19.clear();
            field20.clear();
            label3.setText("");
            label4.setText("");
        });
        
        btn1.setOnAction(event -> {
            int sortArray[] = new int[10];
            
            String str1 = field11.getText();
            int num1 = Integer.parseInt(str1);
            sortArray[0] = num1;
            
            String str2 = field12.getText();
            int num2 = Integer.parseInt(str2);
            sortArray[1] = num2;
            
            String str3 = field13.getText();
            int num3 = Integer.parseInt(str3);
            sortArray[2] = num3;
            
            String str4 = field14.getText();
            int num4 = Integer.parseInt(str4);
            sortArray[3] = num4;
            
            String str5 = field15.getText();
            int num5 = Integer.parseInt(str5);
            sortArray[4] = num5;
            
            String str6 = field16.getText();
            int num6 = Integer.parseInt(str6);
            sortArray[5] = num6;
            
            String str7 = field17.getText();
            int num7 = Integer.parseInt(str7);
            sortArray[6] = num7;
            
            String str8 = field18.getText();
            int num8 = Integer.parseInt(str8);
            sortArray[7] = num8;
            
            String str9 = field19.getText();
            int num9 = Integer.parseInt(str9);
            sortArray[8] = num9;
            
            String str10 = field20.getText();
            int num10 = Integer.parseInt(str10);
            sortArray[9] = num10;
            
            String string3 = "";
            
            for (int i = 0; i < sortArray.length-1; i++)
        {
            int index = i; 
            
            for (int n:sortArray){
                System.out.print(n);
                string3 = string3 + n + " ";
                System.out.print(", ");
            }
            string3 += "\n";
            System.out.println(" ");
            for (int j = i+1; j< sortArray.length; j++)
                if (sortArray[j] < sortArray[index])
                    index = j;
            
            int smallerNumber = sortArray[index];
            sortArray[index] = sortArray[i];
            sortArray[i] = smallerNumber;
        }
            String string4 = "";
            for (int i = 0; i <10; i++) {
                string4 = string4 + Integer.toString(sortArray[i]) + " ";
            }
            label3.setPadding(new Insets(0,100,0,400));
            label3.setText(string3);
            label4.setPadding(new Insets(0,50,0,400));
            label4.setText("Sorted array: " + string4);
            
                 
        });
        
        btn.setOnAction(event -> {
            Random rd = new Random();
                int[] arr = new int[10];
            for (int i = 0; i < arr.length; i++) {
                arr[i] = rd.nextInt(1000); 
                System.out.println(arr[i]);
            }
                
            field11.setText(Integer.toString(arr[0]));   
            field12.setText(Integer.toString(arr[1]));
            field13.setText(Integer.toString(arr[2]));
            field14.setText(Integer.toString(arr[3]));
            field15.setText(Integer.toString(arr[4]));
            field16.setText(Integer.toString(arr[5]));
            field17.setText(Integer.toString(arr[6]));
            field18.setText(Integer.toString(arr[7]));
            field19.setText(Integer.toString(arr[8]));
            field20.setText(Integer.toString(arr[9]));
            
                
        });

        //third tab is for selection sort
        
        TextField field21 = new TextField();
        TextField field22 = new TextField();
        TextField field23 = new TextField();
        TextField field24 = new TextField();
        TextField field25 = new TextField();
        TextField field26 = new TextField();
        TextField field27 = new TextField();
        TextField field28 = new TextField();
        TextField field29 = new TextField();
        TextField field30 = new TextField();
        HBox fieldHbox2 = new HBox();
        fieldHbox2.getChildren().addAll(field21, field22, field23, field24, field25, field26, field27, field28, field29, field30);
        
        Label label5 = new Label();
        Label label6 = new Label();
        
        Button btn3 = new Button("Generate Random Numbers");
        Button btn4 = new Button("Start Insertion Sort");
        Button btn5 = new Button("Reset Numbers");
        HBox buttonHbox2 = new HBox();
        buttonHbox2.setAlignment(Pos.CENTER);
        buttonHbox2.getChildren().addAll(btn3, btn4, btn5);
        
        Tab tab4 = new Tab();
        tab4.setGraphic(new Circle(0,0,10));
        tab4.setText("Insertion Sort");
        HBox hbox4 = new HBox();
        hbox4.getChildren().add
        (new Label("\n" + "                             Insertion Sort Description:" + "\n" + "\n" + "   Insertion Sort splits an array into a sorted and an unsorted part. Values from the unsorted part are picked and placed at the correct position in the sorted part."));
        VBox vbox2 = new VBox();
        vbox2.setSpacing(100);
        vbox2.getChildren().addAll(hbox4, fieldHbox2, buttonHbox2, label5, label6);
        hbox4.setAlignment(Pos.TOP_CENTER);
        tab4.setContent(vbox2);
        tabpane.getTabs().add(tab4); 
        
        btn5.setOnAction(event -> {
            field21.clear();
            field22.clear();
            field23.clear();
            field24.clear();
            field25.clear();
            field26.clear();
            field27.clear();
            field28.clear();
            field29.clear();
            field30.clear();
            label5.setText("");
            label6.setText("");
        });
        
        btn3.setOnAction(event -> {
            Random rd = new Random();
                int[] arr = new int[10];
            for (int i = 0; i < arr.length; i++) {
                arr[i] = rd.nextInt(1000); 
                System.out.println(arr[i]);
            }
                
            field21.setText(Integer.toString(arr[0]));   
            field22.setText(Integer.toString(arr[1]));
            field23.setText(Integer.toString(arr[2]));
            field24.setText(Integer.toString(arr[3]));
            field25.setText(Integer.toString(arr[4]));
            field26.setText(Integer.toString(arr[5]));
            field27.setText(Integer.toString(arr[6]));
            field28.setText(Integer.toString(arr[7]));
            field29.setText(Integer.toString(arr[8]));
            field30.setText(Integer.toString(arr[9]));
            
                
        });
        
        btn4.setOnAction(event -> {
            int insertionArray[] = new int[10];
            
            String str1 = field21.getText();
            int num1 = Integer.parseInt(str1);
            insertionArray[0] = num1;
            
            String str2 = field22.getText();
            int num2 = Integer.parseInt(str2);
            insertionArray[1] = num2;
            
            String str3 = field23.getText();
            int num3 = Integer.parseInt(str3);
            insertionArray[2] = num3;
            
            String str4 = field24.getText();
            int num4 = Integer.parseInt(str4);
            insertionArray[3] = num4;
            
            String str5 = field25.getText();
            int num5 = Integer.parseInt(str5);
            insertionArray[4] = num5;
            
            String str6 = field26.getText();
            int num6 = Integer.parseInt(str6);
            insertionArray[5] = num6;
            
            String str7 = field27.getText();
            int num7 = Integer.parseInt(str7);
            insertionArray[6] = num7;
            
            String str8 = field28.getText();
            int num8 = Integer.parseInt(str8);
            insertionArray[7] = num8;
            
            String str9 = field29.getText();
            int num9 = Integer.parseInt(str9);
            insertionArray[8] = num9;
            
            String str10 = field30.getText();
            int num10 = Integer.parseInt(str10);
            insertionArray[9] = num10;
            
            String string5 = "";
            int temp;
            for (int i = 1; i<insertionArray.length; i++)
        {        
            for (int j=i; j> 0; j--)
            {
                if (insertionArray[j] < insertionArray[j-1])
                {
                    for (int n:insertionArray){
                System.out.print(n);
                string5 = string5 + n + " ";
                System.out.print(", ");
            }
            string5 += "\n";
                    temp = insertionArray[j];
                    insertionArray[j] = insertionArray[j-1];
                    insertionArray[j-1] = temp;
                }
            }
        }
            
            String string6 = "";
            for (int i = 0; i <10; i++) {
                string6 = string6 + Integer.toString(insertionArray[i]) + " ";
            }
            label5.setPadding(new Insets(0,100,0,400));
            label5.setText(string5);
            label6.setPadding(new Insets(0,50,0,400));
            label6.setText("Sorted array: " + string6);
            
                 
        });
        //fourth tab is for insertion sort
        
        TextField field31 = new TextField();
        TextField field32 = new TextField();
        TextField field33 = new TextField();
        TextField field34 = new TextField();
        TextField field35 = new TextField();
        TextField field36 = new TextField();
        TextField field37 = new TextField();
        TextField field38 = new TextField();
        TextField field39 = new TextField();
        TextField field40 = new TextField();
        HBox fieldHbox3 = new HBox();
        fieldHbox3.getChildren().addAll(field31, field32, field33, field34, field35, field36, field37, field38, field39, field40);
        
        Button btn6 = new Button("Generate Random Numbers");
        Button btn7 = new Button("Start Merge Sort");
        Button btn8 = new Button("Reset Numbers");
        HBox buttonHbox3 = new HBox();
        buttonHbox3.setAlignment(Pos.CENTER);
        buttonHbox3.getChildren().addAll(btn6, btn7, btn8);
        
        Label label7 = new Label();
        Label label8 = new Label();
            
        Tab tab5 = new Tab();
        tab5.setGraphic(new Circle(0,0,10));
        tab5.setText("Merge Sort");
        HBox hbox5 = new HBox();
        hbox5.getChildren().add
        (new Label("\n" + "                             Merge Sort Description:" + "\n" + "\n" + "   Merge Sort divides the input array into two halves, calls itself for the two halves, and then merges the two sorted halves"));
        VBox vbox3 = new VBox();
        vbox3.setSpacing(100);
        vbox3.getChildren().addAll(hbox5, fieldHbox3, buttonHbox3, label7, label8);
        hbox5.setAlignment(Pos.TOP_CENTER);
        tab5.setContent(vbox3);
        tabpane.getTabs().add(tab5); 
        
        MergeSort merge = new MergeSort();
        
        btn8.setOnAction(event -> {
            field31.clear();
            field32.clear();
            field33.clear();
            field34.clear();
            field35.clear();
            field36.clear();
            field37.clear();
            field38.clear();
            field39.clear();
            field40.clear();   
            label7.setText("");
            label8.setText("");
            
        });
        
        btn6.setOnAction(event -> {
            Random rd = new Random();
                int[] arr = new int[10];
            for (int i = 0; i < arr.length; i++) {
                arr[i] = rd.nextInt(1000); 
                System.out.println(arr[i]);
            }
                
            field31.setText(Integer.toString(arr[0]));   
            field32.setText(Integer.toString(arr[1]));
            field33.setText(Integer.toString(arr[2]));
            field34.setText(Integer.toString(arr[3]));
            field35.setText(Integer.toString(arr[4]));
            field36.setText(Integer.toString(arr[5]));
            field37.setText(Integer.toString(arr[6]));
            field38.setText(Integer.toString(arr[7]));
            field39.setText(Integer.toString(arr[8]));
            field40.setText(Integer.toString(arr[9]));
            
                
        });
        
        btn7.setOnAction(event -> {
            int mergeArray[] = new int[10];
            
            String str1 = field31.getText();
            int num1 = Integer.parseInt(str1);
            mergeArray[0] = num1;
            
            String str2 = field32.getText();
            int num2 = Integer.parseInt(str2);
            mergeArray[1] = num2;
            
            String str3 = field33.getText();
            int num3 = Integer.parseInt(str3);
            mergeArray[2] = num3;
            
            String str4 = field34.getText();
            int num4 = Integer.parseInt(str4);
            mergeArray[3] = num4;
            
            String str5 = field35.getText();
            int num5 = Integer.parseInt(str5);
            mergeArray[4] = num5;
            
            String str6 = field36.getText();
            int num6 = Integer.parseInt(str6);
            mergeArray[5] = num6;
            
            String str7 = field37.getText();
            int num7 = Integer.parseInt(str7);
            mergeArray[6] = num7;
            
            String str8 = field38.getText();
            int num8 = Integer.parseInt(str8);
            mergeArray[7] = num8;
            
            String str9 = field39.getText();
            int num9 = Integer.parseInt(str9);
            mergeArray[8] = num9;
            
            String str10 = field40.getText();
            int num10 = Integer.parseInt(str10);
            mergeArray[9] = num10;
            
            String string7 = "";
            
            
            string7 = merge.mergeSort(mergeArray, 0, mergeArray.length - 1);
            //string7 = merge.mergeSort();
            
            String string8 = "";
            for (int i = 0; i <10; i++) {
                string8 = string8 + Integer.toString(mergeArray[i]) + " ";
            }
            label7.setPadding(new Insets(0,100,0,400));
            label7.setText(string7);
            label8.setPadding(new Insets(0,50,0,400));
            label8.setText("Sorted array: " + string8);
            
                 
        });
        //fifth tab is for merge sort
        
        
        
        TextField field41 = new TextField();
        TextField field42 = new TextField();
        TextField field43 = new TextField();
        TextField field44 = new TextField();
        TextField field45 = new TextField();
        TextField field46 = new TextField();
        TextField field47 = new TextField();
        TextField field48 = new TextField();
        TextField field49 = new TextField();
        TextField field50 = new TextField();
        HBox fieldHbox4 = new HBox();
        fieldHbox4.getChildren().addAll(field41, field42, field43, field44, field45, field46, field47, field48, field49, field50);
        
        Button btn9 = new Button("Generate Random Numbers");
        Button btn10 = new Button("Start Quick Sort");
        Button btn11 = new Button("Reset Numbers");
        HBox buttonHbox4 = new HBox();
        buttonHbox4.setAlignment(Pos.CENTER);
        buttonHbox4.getChildren().addAll(btn9, btn10, btn11);
        
        Label label9 = new Label();
        Label label10 = new Label();
        
        Tab tab6 = new Tab();
        tab6.setGraphic(new Circle(0,0,10));
        tab6.setText("Quick Sort");
        HBox hbox6 = new HBox();
        hbox6.getChildren().add
        (new Label("\n" + "                             Quick Sort Description:" + "\n" + "\n" + "   Quick Sort picks an element as a 'pivot' and partitions the given array around the picked pivot."));
        VBox vbox4 = new VBox();
        vbox4.setSpacing(100);
        vbox4.getChildren().addAll(hbox6, fieldHbox4, buttonHbox4, label9, label10);
        hbox6.setAlignment(Pos.TOP_CENTER);
        tab6.setContent(vbox4);
        tabpane.getTabs().add(tab6); 
        
        QuickSort quick = new QuickSort();
        
        btn11.setOnAction(event -> {
            field41.clear();
            field42.clear();
            field43.clear();
            field44.clear();
            field45.clear();
            field46.clear();
            field47.clear();
            field48.clear();
            field49.clear();
            field50.clear();
            label9.setText("");
            label10.setText("");
        });
        
        
        btn9.setOnAction(event -> {
            Random rd = new Random();
                int[] arr = new int[10];
            for (int i = 0; i < arr.length; i++) {
                arr[i] = rd.nextInt(1000); 
                System.out.println(arr[i]);
            }
                
            field41.setText(Integer.toString(arr[0]));   
            field42.setText(Integer.toString(arr[1]));
            field43.setText(Integer.toString(arr[2]));
            field44.setText(Integer.toString(arr[3]));
            field45.setText(Integer.toString(arr[4]));
            field46.setText(Integer.toString(arr[5]));
            field47.setText(Integer.toString(arr[6]));
            field48.setText(Integer.toString(arr[7]));
            field49.setText(Integer.toString(arr[8]));
            field50.setText(Integer.toString(arr[9]));
        });
        
        btn10.setOnAction(event -> {
            int quickArray[] = new int[10];
            
            String str1 = field41.getText();
            int num1 = Integer.parseInt(str1);
            quickArray[0] = num1;
            
            String str2 = field42.getText();
            int num2 = Integer.parseInt(str2);
            quickArray[1] = num2;
            
            String str3 = field43.getText();
            int num3 = Integer.parseInt(str3);
            quickArray[2] = num3;
            
            String str4 = field44.getText();
            int num4 = Integer.parseInt(str4);
            quickArray[3] = num4;
            
            String str5 = field45.getText();
            int num5 = Integer.parseInt(str5);
            quickArray[4] = num5;
            
            String str6 = field46.getText();
            int num6 = Integer.parseInt(str6);
            quickArray[5] = num6;
            
            String str7 = field47.getText();
            int num7 = Integer.parseInt(str7);
            quickArray[6] = num7;
            
            String str8 = field48.getText();
            int num8 = Integer.parseInt(str8);
            quickArray[7] = num8;
            
            String str9 = field49.getText();
            int num9 = Integer.parseInt(str9);
            quickArray[8] = num9;
            
            String str10 = field50.getText();
            int num10 = Integer.parseInt(str10);
            quickArray[9] = num10;
            
            String string9 = "";
            
            
            //string9 = quick.quickSort(quickArray, 0, quickArray.length - 1);
            string9 = quick.main(quickArray);
            
            
            String string10 = "";
            for (int i = 0; i <10; i++) {
                string10 = string10 + Integer.toString(quickArray[i]) + " ";
            }
            label9.setPadding(new Insets(0,100,0,400));
            label9.setText(string9);
            label10.setPadding(new Insets(0,50,0,400));
            label10.setText("Sorted array: " + string10);
            
                 
        });
        
        
        borderpane.prefHeightProperty().bind
            (scene.heightProperty());
        borderpane.prefWidthProperty().bind
            (scene.widthProperty());
        
        borderpane.setCenter(tabpane);
        root.getChildren().add(borderpane);
        
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    public static void main(String[] args) {
        launch(args);
    }
    
}
