package sortingproject;

import java.util.*;
public class QuickSort { 
        public static String main(int[] array) 
    {
        String str2 = "";
        
        // This is unsorted array
        //Integer[] array = new Integer[] { 12, 13, 24, 10, 3, 6, 90, 70 };
 
        // Let's sort using quick sort
        str2 = quickSort( array, 0, array.length - 1 );
 
        // Verify sorted array
        
        System.out.println(Arrays.toString(array));
        return str2;
        
        
    }
 
    public static String quickSort(int[] arr, int low, int high) 
    {
        String str = "";
        //check for empty or null array
        if (arr == null || arr.length == 0){
            
            //return;
        }
         
        if (low >= high){
            //return;
        }
 
        //Get the pivot element from the middle of the list
        int middle = low + (high - low) / 2;
        int pivot = arr[middle];
 
        // make left < pivot and right > pivot
        int i = low, j = high;
        while (i <= j) 
        {
            //Check until all values on left side array are lower than pivot
            while (arr[i] < pivot) 
            {
                i++;
            }
            //Check until all values on left side array are greater than pivot
            while (arr[j] > pivot) 
            {
                j--;
            }
            //Now compare values from both side of lists to see if they need swapping 
            //After swapping move the iterator on both lists
            if (i <= j) 
            {
                
                str += swap (arr, i, j);
                i++;
                j--;
                
            }
        }
        //Do same operation as above recursively to sort two sub arrays
        if (low < j){
            str += quickSort(arr, low, j);
        }
        if (high > i){
            str += quickSort(arr, i, high);
        }
        return str;
    }
     
    public static String swap (int[] array, int x, int y)
    {
        
        String string9 = "";
//        for (int n:array){
//                System.out.print(n);
//                
//                string9 = string9 + n + " ";
//                System.out.print(", ");
//            }
//                string9 += "\n";
                
        int temp = array[x];
        array[x] = array[y];
        array[y] = temp;
        
        for (int i = 0; i < 10;i++) {
            string9 += array[i] + " ";
            
        }
        string9 += "\n";
        System.out.println(string9);
        return string9;
        
    }
}

