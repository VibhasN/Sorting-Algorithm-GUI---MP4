module com.mycompany.mavenproject1 {
    requires javafx.controls;
    exports com.mycompany.mavenproject1;
}
