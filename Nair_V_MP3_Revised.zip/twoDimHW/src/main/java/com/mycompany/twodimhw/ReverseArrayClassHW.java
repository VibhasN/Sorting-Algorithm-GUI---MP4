package com.mycompany.twodimhw;

/**
 *
 * @author vn272
 */
public class ReverseArrayClassHW {
    //this flips the array horizontally and stores in a new array variable which is then returned
    public static int[][] flipArrayHorizontally(int[][] original) {
        int [][] flipHArray = new int[TwoDimArrayHW.getRow()][TwoDimArrayHW.getCol()];
        for (int i = 0; i < TwoDimArrayHW.getRow(); i++) {
            for (int j = 0; j < TwoDimArrayHW.getCol(); j++) {
                flipHArray[(TwoDimArrayHW.getRow() - 1) - i][j] = original[i][j];
            }
        }
        return flipHArray;
    }
    //this flips the array vertically and stores in a new array variable which is then returned
    public static int[][] flipArrayVertically(int[][] original) {
        int [][] flipVArray = new int[TwoDimArrayHW.getRow()][TwoDimArrayHW.getCol()];
        for (int i = 0; i < TwoDimArrayHW.getRow(); i++) {
            for (int j = 0; j < TwoDimArrayHW.getCol(); j++) {
                flipVArray[i][(TwoDimArrayHW.getCol() - 1) - j] = original[i][j];
            }
        }
        return flipVArray;
    }
    //this reverses the original array and then stores it in a new array variable which is then returned 
    public static int[][] reverseArray(int[][] original) {
        int [][] yarrA = new int[TwoDimArrayHW.getRow()][TwoDimArrayHW.getCol()];
        for (int i = 0; i < TwoDimArrayHW.getRow(); i++) {
            for (int j = 0; j < TwoDimArrayHW.getCol(); j++) {
                yarrA[(TwoDimArrayHW.getRow() - 1) - i][(TwoDimArrayHW.getCol() - 1) - j] = original[i][j];
            }
        }
        return yarrA;
    }
    //this transposes the array (essentially switching the TwoDimArrayHW.getRow()s and TwoDimArrayHW.getCol()umns) and
    //stores it in a new array variable which is then returned
    public static int[][] transposeArray(int[][] original) {
        int [][] tPoseArray = new int[TwoDimArrayHW.getCol()][TwoDimArrayHW.getRow()];
        for (int i = 0; i < TwoDimArrayHW.getCol(); i++) {
            for (int j = 0; j < TwoDimArrayHW.getRow(); j++) {
                tPoseArray[i][j] = original[j][i];
            }
        }
        return tPoseArray;
    }
    //this again transposes the array and on top of that, reverses it
    //it then stores the variable in a new array variable which is then returned
    public static int[][] reverseTransposeArray(int[][] original) {
        int [][] rTPoseArray = new int [TwoDimArrayHW.getCol()][TwoDimArrayHW.getRow()];
        for (int i = 0; i < TwoDimArrayHW.getCol(); i++) {
            for (int j = 0; j < TwoDimArrayHW.getRow(); j++) {
                rTPoseArray[(TwoDimArrayHW.getCol() - 1) - i][(TwoDimArrayHW.getRow() - 1) - j] = original[j][i];
            }
        }
        return rTPoseArray;
    }
    
    public static double[][] flipArrayHorizontally(double[][] original) {
        double [][] flipHArray = new double[TwoDimArrayHW.getRow()][TwoDimArrayHW.getCol()];
        for (int i = 0; i < TwoDimArrayHW.getRow(); i++) {
            for (int j = 0; j < TwoDimArrayHW.getCol(); j++) {
                flipHArray[2 - i][j] = original[i][j];
            }
        }
        return flipHArray;
    }
    //this flips the array vertically and stores in a new array variable which is then returned
    public static double[][] flipArrayVertically(double[][] original) {
        double [][] flipVArray = new double[TwoDimArrayHW.getRow()][TwoDimArrayHW.getCol()];
        for (int i = 0; i < TwoDimArrayHW.getRow(); i++) {
            for (int j = 0; j < TwoDimArrayHW.getCol(); j++) {
                flipVArray[i][(TwoDimArrayHW.getCol() - 1) - j] = original[i][j];
            }
        }
        return flipVArray;
    }
    //this reverses the original array and then stores it in a new array variable which is then returned 
    public static double[][] reverseArray(double[][] original) {
        double [][] yarrA = new double[TwoDimArrayHW.getRow()][TwoDimArrayHW.getCol()];
        for (int i = 0; i < TwoDimArrayHW.getRow(); i++) {
            for (int j = 0; j < TwoDimArrayHW.getCol(); j++) {
                yarrA[(TwoDimArrayHW.getRow() - 1) - i][(TwoDimArrayHW.getCol() - 1) - j] = original[i][j];
            }
        }
        return yarrA;
    }
    //this transposes the array (essentially switching the TwoDimArrayHW.getRow()s and TwoDimArrayHW.getCol()umns) and
    //stores it in a new array variable which is then returned
    public static double[][] transposeArray(double[][] original) {
        double [][] tPoseArray = new double[TwoDimArrayHW.getCol()][TwoDimArrayHW.getRow()];
        for (int i = 0; i < TwoDimArrayHW.getCol(); i++) {
            for (int j = 0; j < TwoDimArrayHW.getRow(); j++) {
                tPoseArray[i][j] = original[j][i];
            }
        }
        return tPoseArray;
    }
    //this again transposes the array and on top of that, reverses it
    //it then stores the variable in a new array variable which is then returned
    public static double[][] reverseTransposeArray(double[][] original) {
        double [][] rTPoseArray = new double [TwoDimArrayHW.getCol()][TwoDimArrayHW.getRow()];
        for (int i = 0; i < TwoDimArrayHW.getCol(); i++) {
            for (int j = 0; j < TwoDimArrayHW.getRow(); j++) {
                rTPoseArray[(TwoDimArrayHW.getCol() - 1) - i][(TwoDimArrayHW.getRow() - 1) - j] = original[j][i];
            }
        }
        return rTPoseArray;
    }
}
