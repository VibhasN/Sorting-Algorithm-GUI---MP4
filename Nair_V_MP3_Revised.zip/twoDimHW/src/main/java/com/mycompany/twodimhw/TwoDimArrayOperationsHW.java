package com.mycompany.twodimhw;

/**
 *
 * @author vn272
 */
public class TwoDimArrayOperationsHW extends ReverseArrayClassHW{
    //prints out the array
    public static void printArray(int[][] array) {
        System.out.println("Printing the array: ");
        for (int i = 0; i < TwoDimArrayHW.getRow(); i++) {
            for (int j = 0; j < TwoDimArrayHW.getCol(); j++) {
                System.out.print("[" + i + "][" + j + "] = " + array[i][j] + "\t");
            }
            System.out.println();
        }
        System.out.println("\n");
    }
    //prints out the array when using the transpose methods
    public static void printArray2(int[][] array) {
        System.out.println("Printing the array: ");
        for (int i = 0; i < TwoDimArrayHW.getCol(); i++) {
            for (int j = 0; j < TwoDimArrayHW.getRow(); j++) {
                System.out.print("[" + i + "][" + j + "] = " + array[i][j] + "\t");
            }
            System.out.println();
        }
        System.out.println("\n");
    }
    //gets the total of all the values in the array
    public static int getTotal(int[][] array) {
        int total = 0;
        for (int i = 0; i < TwoDimArrayHW.getRow(); i++) {
            for (int j = 0; j < TwoDimArrayHW.getCol(); j++) {
                total += array[i][j];
            }
        }
        return total; 
    }
    //gets the average of all the values in the array 
    public static int getAverage(int[][] array) {
        int sum = 0;
        for (int i = 0; i < TwoDimArrayHW.getRow(); i++) {
            for (int j = 0; j < TwoDimArrayHW.getCol(); j++) {
                sum += array[i][j];
            }
        }
        int average = sum / (TwoDimArrayHW.getRow() * TwoDimArrayHW.getCol());
        return average;
    }
    //gets the total value of all the values of a particular row 
    public static int getRowTotal(int[][] array, int row) {
        int total = 0;
        for (int i = 0; i < TwoDimArrayHW.getCol(); i++) {
            total += array[row][i];
        }
        return total;
    }
    //gets the total value of all the values of a particular column 
    public static int getColumnTotal(int[][] array, int col) {
        int total = 0;
        for (int i = 0; i < TwoDimArrayHW.getRow(); ++i) {
            total += array[i][col];
        }
        return total;
    }
    //gets the highest value in a particular row 
    public static int getHighestInRow(int[][] array, int row) {
        int maxVal = array[row][0];
        for (int i = 0; i < TwoDimArrayHW.getCol(); i++) {
            if (array[row][i] > maxVal) {
                maxVal = array[row][i];
            }
        }
        return maxVal;
    }
    //gets the lowest value in a particular row 
    public static int getLowestInRow(int[][] array, int row) {
        int minVal = array[row][0];
        for (int i = 0; i < TwoDimArrayHW.getCol(); i++) {
            if (minVal > array[row][0]) {
                minVal = array[row][0];
            }
        }
        return minVal;
    }
    //this counts the number of elements in the array which should always be 1col
    //also this method is never used 
    public static int getElementCount(int[][] array) {
        int count = 0;
        for (int i = 0; i < TwoDimArrayHW.getRow(); i++) {
            for (int j = 0; j < TwoDimArrayHW.getCol(); j++) {
                count++;
            }
        }
        return count;
    }
    
    public static void printArray(double[][] array) {
        System.out.println("Printing the array: ");
        for (int i = 0; i < TwoDimArrayHW.getRow(); i++) {
            for (int j = 0; j < TwoDimArrayHW.getCol(); j++) {
                System.out.print("[" + i + "][" + j + "] = " + array[i][j] + "\t");
            }
            System.out.println();
        }
        System.out.println("\n");
    }
    //prints out the array when using the transpose methods
    public static void printArray2(double[][] array) {
        System.out.println("Printing the array: ");
        for (int i = 0; i < TwoDimArrayHW.getCol(); i++) {
            for (int j = 0; j < TwoDimArrayHW.getRow(); j++) {
                System.out.print("[" + i + "][" + j + "] = " + array[i][j] + "\t");
            }
            System.out.println();
        }
        System.out.println("\n");
    }
    //gets the total of all the values in the array
    public static double getTotal(double[][] array) {
        int total = 0;
        for (int i = 0; i < TwoDimArrayHW.getRow(); i++) {
            for (int j = 0; j < TwoDimArrayHW.getCol(); j++) {
                total += array[i][j];
            }
        }
        return total; 
    }
    //gets the average of all the values in the array 
    public static double getAverage(double[][] array) {
        int sum = 0;
        for (int i = 0; i < TwoDimArrayHW.getRow(); i++) {
            for (int j = 0; j < TwoDimArrayHW.getCol(); j++) {
                sum += array[i][j];
            }
        }
        int average = sum / (TwoDimArrayHW.getCol() * TwoDimArrayHW.getRow());
        return average;
    }
    //gets the total value of all the values of a particular row 
    public static double getRowTotal(double[][] array, int row) {
        int total = 0;
        for (int i = 0; i < TwoDimArrayHW.getCol(); i++) {
            total += array[row][i];
        }
        return total;
    }
    //gets the total value of all the values of a particular column 
    public static double getColumnTotal(double[][] array, int col) {
        int total = 0;
        for (int i = 0; i < TwoDimArrayHW.getRow(); ++i) {
            total += array[i][col];
        }
        return total;
    }
    //gets the highest value in a particular row 
    public static double getHighestInRow(double[][] array, int row) {
        double maxVal = array[row][0];
        for (int i = 0; i < TwoDimArrayHW.getCol(); i++) {
            if (array[row][i] > maxVal) {
                maxVal = array[row][i];
            }
        }
        return maxVal;
    }
    //gets the lowest value in a particular row 
    public static double getLowestInRow(double[][] array, int row) {
        double minVal = array[row][0];
        for (int i = 0; i < TwoDimArrayHW.getCol(); i++) {
            if (minVal > array[row][0]) {
                minVal = array[row][0];
            }
        }
        return minVal;
    }
}
