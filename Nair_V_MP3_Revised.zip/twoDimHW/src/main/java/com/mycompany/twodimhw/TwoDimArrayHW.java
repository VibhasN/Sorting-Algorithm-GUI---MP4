package com.mycompany.twodimhw;

import java.util.Scanner;

/**
 *
 * @author vn272
 */
public class TwoDimArrayHW extends TwoDimArrayOperationsHW{
    public static int roW;
    public static int coL; 

    public static int getRow() {
        return roW;
    }

    public static void setRow(int roW) {
        TwoDimArrayHW.roW = roW;
    }

    public static int getCol() {
        return coL;
    }

    public static void setCol(int col) {
        TwoDimArrayHW.coL = coL;
    }
    
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        // declare twoDimHW to be a 2-dimensional array of integers of 3 rows and 5 columns
        System.out.println("Input a row value: ");
        roW = scan.nextInt();
        System.out.println("Input a column value: ");
        coL = scan.nextInt();
        int [][] twoDimHW = new int[roW][coL];
        // Insert Code here to ask the user to fill out the array 
        System.out.println("Please fill out the [" + roW + "x" + coL + "] array: ");
        for (int i = 0; i < roW; i++) {
            for (int j = 0; j < coL; j++) {
                System.out.println("Please enter an integer value for twoDimHW[" + i + "][" + j + "]: ");
                //twoDimHW[i][j] = scan.nextInt();
                if (!scan.hasNextInt()) {
                    System.out.println("Please enter an integer.");
                    System.exit(0);
                } else {
                    twoDimHW[i][j] = scan.nextInt();
                }
            }
        }
        // Use printArray method to print the array “twoDimHW”
        printArray(twoDimHW);
        
        // declare numbersReverse to be a 2-dimensional array 
        int[][] numbersReverse = new int[roW][coL];
        // use flipArrayHorizontally method to fill it out by flipping the “twoDimHW” horizontally
        numbersReverse = flipArrayHorizontally(twoDimHW);
        // Use printArray method to print the array “numbersReverse”
        System.out.println("Flipping the array horizontally:");
        printArray(numbersReverse);
        
        // declare flipArrVer to be a 2-dimensional array 
        int [][] flipArrVer = new int[roW][coL];
        // use flipArrayVertically method to fill it out by flipping the “twoDimHW” vertically;
        flipArrVer = flipArrayVertically(twoDimHW);
        // Use printArray method to print the array “flipArrVer”
        System.out.println("Flipping the array vertically:");
        printArray(flipArrVer);
        
        // declare reverseArr to be a 2-dimensional array 
        int [][] reverseArr = new int[roW][coL];
        // use reverseArray method to fill it out by reversing the “twoDimHW”;
        reverseArr = reverseArray(twoDimHW);
        // Use printArray method to print the array “reverseArr”
        System.out.println("Reversing the array:");
        printArray(reverseArr);
        
        // declare transpArr to be a 2-dimensional array 
        int[][] transpArr = new int[roW][coL];
        // use transposeArray method to fill it out by transposing the “twoDimHW”;
        transpArr = transposeArray(twoDimHW);
        // Use printArray method to print the array “transposeArray”
        System.out.println("Transposing the array:");
        printArray2(transpArr);
        
        // declare reverseTranspArr to be a 2-dimensional array 
        int[][] reverseTranspArr = new int[roW][coL];
        // use reverseTransposeArray method to fill it out by reversing and transposing the “twoDimHW”;
        reverseTranspArr = reverseTransposeArray(twoDimHW);
        // Use printArray method to print the array “reverseTranspArr”
        System.out.println("Reversing and transposing the array:");
        printArray2(reverseTranspArr);
        
        // Use printArray method to print the array “twoDimHW”     
        printArray(twoDimHW);
        
        // Apply the getTotal method on the “twoDimHW” array
        System.out.println("Total of twoDimHW: " + getTotal(twoDimHW));
        // Apply the getAverage method on the “twoDimHW” array
        System.out.println("Average of twoDimHW: " + getAverage(twoDimHW));
        // Apply the getRowTotal method on row 0 of the “twoDimHW” array
        System.out.println("Total of row 0 of twoDimHW: " + getRowTotal(twoDimHW, 0));
        // Apply the getRowTotal method on row 1 of the “twoDimHW” array
        System.out.println("Total of row 1 of twoDimHW: " + getRowTotal(twoDimHW, 1));
        // Apply the getColumnTotal method on column 0 of the “twoDimHW” array
        System.out.println("Total of col 0 of twoDimHW: " + getColumnTotal(twoDimHW, 0));
        // Apply the getColumnTotal method on column 2 of the “twoDimHW” array
        System.out.println("Total of col 1 of twoDimHW: " + getColumnTotal(twoDimHW, 1));
        // Apply the getHighestInRow method on row 0 of the “twoDimHW” array
        System.out.println("Highest in row 0 of twoDimHW: " + getHighestInRow(twoDimHW, 0));
        // Apply the getHighestInRow method on row 1 of the “twoDimHW” array
        System.out.println("Highest in row 1 of twoDimHW: " + getHighestInRow(twoDimHW, 1));
        // Apply the getLowestInRow method on row 0 of the “twoDimHW” array
        System.out.println("Lowest in row 0 of twoDimHW: " + getLowestInRow(twoDimHW, 0));
        // Apply the getLowestInRow method on row 1 of the “twoDimHW” array
        System.out.println("Lowest in row 1 of twoDimHW: " + getLowestInRow(twoDimHW, 1));
    }
    
}
